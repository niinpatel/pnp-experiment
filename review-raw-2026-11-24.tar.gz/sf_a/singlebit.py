import itertools, math, sys
from fractions import Fraction
import numpy as np
# single-bit identity of App. H: cross = T1 + T2, T1=[x=u][y=v], T2=-[x!=y](-1)^x [u!=v](-1)^u
def T1(x,y,u,v): return int(x==u and y==v)
def T2(x,y,u,v): return -int(x!=y)*(-1)**x*int(u!=v)*(-1)**u
for x,y,u,v in itertools.product((0,1),repeat=4):
    assert T1(x,y,u,v)+T2(x,y,u,v)==int(x==v and y==u)
def pieces(t):
    # A_i = sum over subsets Q of size i taking T2, others T1 ; tensor index order per block (x,y,u,v)
    idx=list(itertools.product((0,1),repeat=t))
    n=len(idx)
    A=[np.zeros((n,n,n,n),dtype=object) for _ in range(t+1)]
    for X in range(n):
      for Y in range(n):
        for U in range(n):
          for V in range(n):
            # polynomial in T
            poly=[1]+[0]*t
            for s in range(t):
                a=T1(idx[X][s],idx[Y][s],idx[U][s],idx[V][s]); b=T2(idx[X][s],idx[Y][s],idx[U][s],idx[V][s])
                new=[0]*(t+1)
                for d in range(t+1):
                    if poly[d]==0: continue
                    new[d]+=poly[d]*a
                    if d+1<=t: new[d+1]+=poly[d]*b
                poly=new
            for i in range(t+1): A[i][X,Y,U,V]=poly[i]
    return A,n
def rk(M): return np.linalg.matrix_rank(np.array(M,dtype=float))
for t in (1,2,3):
    A,n=pieces(t)
    S=sum(A)
    # check sum = crossing
    ok=all(S[X,Y,U,V]==int(X==V and Y==U) for X in range(n) for Y in range(n) for U in range(n) for V in range(n))
    out=[]
    for i in range(t+1):
        row=A[i].reshape(n*n,n*n)            # (x,y)|(u,v)
        col=A[i].transpose(0,2,1,3).reshape(n*n,n*n)  # (x,u)|(y,v)
        rr,rc=rk(row),rk(col)
        fr=sum(math.comb(t,z)*3**(t-z) for z in range(i,t+1))      # predicted row rank: singlet count z>=i
        fc=sum(math.comb(t,z)*3**(t-z) for z in range(t-i,t+1))    # predicted col rank
        out.append((i,rr,rc,fr,fc,rr*rc,12**t))
    print("t",t,"sum ok",ok,out)
# explicit integer factorisation row-wise for t=2, piece i=1 scaled by 2^t, via product eigenvectors
t=2
A,n=pieces(t)
sing=np.array([0,1,-1,0]); trip=[np.array([1,0,0,0]),np.array([0,0,0,1]),np.array([0,1,1,0])]
basis=[(sing,1,2)]+[(v,0,int(v@v)) for v in trip]   # (vector on (x,y) in order 00,01,10,11, is_singlet, norm^2)
i=1
cols_f=[];cols_g=[]
for combo in itertools.product(basis,repeat=t):
    z=sum(c[1] for c in combo)
    lam=math.comb(z,i)*(-2)**i if z>=i else 0
    if lam==0: continue
    vec=combo[0][0]
    for c in combo[1:]: vec=np.kron(vec,c[0])
    nrm=math.prod(c[2] for c in combo)
    cols_f.append(lam*(2**t//nrm)*vec); cols_g.append(vec)
F=np.array(cols_f).T; G=np.array(cols_g).T
# index order of kron: block1 (x1,y1), block2 (x2,y2) -> need map to (X,Y) with X=(x1,x2),Y=(y1,y2)
def rowmat(Ai):
    M=np.zeros((16,16),dtype=int)
    for x1,y1,x2,y2,u1,v1,u2,v2 in itertools.product((0,1),repeat=8):
        X=x1*2+x2;Y=y1*2+y2;U=u1*2+u2;V=v1*2+v2
        M[(x1*2+y1)*4+(x2*2+y2),(u1*2+v1)*4+(u2*2+v2)]=Ai[X,Y,U,V]
    return M
M=rowmat(A[i])
print("explicit integer row factorisation of 2^t*A_1 (t=2): inner dim",F.shape[1],"exact:",np.array_equal(F@G.T,(2**t)*M),"max |entry|",abs(F).max(),abs(G).max())
