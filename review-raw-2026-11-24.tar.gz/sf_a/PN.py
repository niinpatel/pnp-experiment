import math
NMAX=60000
p=[0]*(NMAX+1); p[0]=1
for n in range(1,NMAX+1):
    s=0;k=1
    while True:
        g1=k*(3*k-1)//2
        if g1>n: break
        sign=1 if k%2 else -1
        s+=sign*p[n-g1]
        g2=k*(3*k+1)//2
        if g2<=n: s+=sign*p[n-g2]
        k+=1
    p[n]=s
assert p[100]==190569292 and p[15]==176
pre=[0]
for x in p: pre.append(pre[-1]+x)
def S(a,b):
    a=max(a,0)
    return pre[b+1]-pre[a] if b>=a else 0
def lg(x):
    b=x.bit_length()
    return (b-60)+math.log2(x>>(b-60)) if b>70 else math.log2(x)
print("lam h  rho_ceil rho_exact | terms=sum_s min(Rrow,Rcol): log2(terms)/lam (exponent of N) ; pieces 4h+1")
for lam in (20,50,100,150,200,300,400):
    h=2
    while p[h]<2**lam: h+=1
    if 4*h>NMAX: print(lam,h,"skip"); continue
    tot=0; best=0; bestc=0
    for s in range(-2*h,2*h+1):
        Rr=S(s,s+2*h); Rc=S(-s,2*h-s)
        tot+=min(Rr,Rc)
        best=max(best,lg(Rr)+lg(Rc)); bestc=max(bestc,math.ceil(lg(Rr))+math.ceil(lg(Rc)))
    print(lam,h,"%.4f %.4f"%(bestc/(4*lam),best/(4*lam)),"| P(N) exponent <= %.4f"%(lg(tot)/lam),"pieces",4*h+1)
