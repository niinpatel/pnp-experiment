import math, sys
from functools import lru_cache
sys.setrecursionlimit(100000)
def partitions_upto(n):
    p=[0]*(n+1); p[0]=1
    for k in range(1,n+1):
        for j in range(k,n+1):
            p[j]+=p[j-k]
    return p
NMAX=13000
p=partitions_upto(NMAX)
def P(e): return p[e] if 0<=e<=NMAX else 0
def log2int(x): return math.log2(x) if x.bit_length()<1000 else (x.bit_length()-1)+math.log2(x>>(x.bit_length()-53))-52
def h_of_lambda(lam):
    h=2
    while P(h) < 2**lam: h+=1
    return h
pre=[0]*(NMAX+2)
for i in range(NMAX+1): pre[i+1]=pre[i]+p[i]
def S(a,b):  # sum p(a..b)
    a=max(a,0); 
    if b<a: return 0
    return pre[b+1]-pre[a]
def stats(h,lam=None):
    best=None
    for s in range(-2*h,2*h+1):
        Rr=S(s,s+2*h); Rc=S(-s,2*h-s)
        if Rr<1 or Rc<1: continue
        lr=log2int(Rr); lc=log2int(Rc)
        ce=math.ceil(lr-1e-12)+math.ceil(lc-1e-12)
        if best is None or lr+lc>best[0]: best=(lr+lc,s,ce,lr,lc)
    return best
print("lambda -> h, variants: (a) ceil-sum/(4lam) (b) exact log-sum/(4lam) (c) log-sum/(4 log p(h)) (d) log p(2h)/(2 log p(h)) (e) log p(2h)/(2 lam) (f) with N^2 cap: min(log R, 2lam)")
for lam in [5,10,20,50,100,200,300]:
    h=h_of_lambda(lam)
    if 4*h>NMAX: print(lam,h,"too big"); continue
    b=stats(h)
    lp=log2int(P(h)); lp2=log2int(P(2*h))
    capped=max(min(math.ceil(log2int(S(s,s+2*h))-1e-12),2*lam)+min(math.ceil(log2int(S(-s,2*h-s))-1e-12),2*lam) for s in range(-2*h,2*h+1))
    print(lam,h,"s*=%d"%b[1],"(a)%.4f"%(b[2]/(4*lam)),"(b)%.4f"%(b[0]/(4*lam)),"(c)%.4f"%(b[0]/(4*lp)),"(d)%.4f"%(lp2/(2*lp)),"(e)%.4f"%(lp2/(2*lam)),"(f)%.4f"%(capped/(4*lam)))
print("by h: (c) log-sum/(4 log2 p(h)); (g) with N=p(h) cap min(logR, 2 log p(h))")
for h in [16,20,32,61,64,128,256,512,1000,3000]:
    b=stats(h); lp=log2int(P(h)); lp2=log2int(P(2*h))
    capped=max(min(log2int(S(s,s+2*h)),2*lp)+min(log2int(S(-s,2*h-s)),2*lp) for s in range(-2*h,2*h+1))
    print(h,"log2p(h)=%.3f"%lp,"s*=%d"%b[1],"(c)%.4f"%(b[0]/(4*lp)),"(d)%.4f"%(lp2/(2*lp)),"(g)%.4f"%(capped/(4*lp)), "R_row(0)>=N^2?", S(0,2*h)>=P(h)**2)
# first h where counted bound at s=0 drops below N^2
for h in range(2,60):
    if S(0,2*h) < P(h)**2:
        print("first h with R_row(0) < p(h)^2:",h,"p(h)^2=",P(h)**2, "R=",S(0,2*h)); break
print("p(16)^2",P(16)**2,"p(15)^2",P(15)**2, "p(17)^2", P(17)**2)
# table check
for (h,s) in [(5,-3),(6,-3),(7,-3),(8,-3),(9,-3),(9,-9)]:
    print(h,s,"R_row",S(s,s+2*h),"R_col",S(-s,2*h-s),"N^2",P(h)**2)
print("full bits h=2..7:",["%.2f"%(2*math.log2(P(h))) for h in range(2,8)])
