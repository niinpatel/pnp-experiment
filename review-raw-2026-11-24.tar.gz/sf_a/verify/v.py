import math, itertools
from fractions import Fraction
N=14000
p=[0]*(N+1); p[0]=1
for part in range(1,N+1):
    for n in range(part,N+1):
        p[n]+=p[n-part]
assert p[100]==190569292
pre=[0]
for x in p: pre.append(pre[-1]+x)
def S(a,b):
    a=max(a,0)
    return pre[b+1]-pre[a] if b>=a else 0
def lg(x):
    b=x.bit_length()
    return (b-60)+math.log2(x>>(b-60)) if b>70 else math.log2(x)
print("A-def: lam h rho_ceil rho_noceil | M-shape(cum D, h least D(h)>=lam): h rho")
for lam in (20,50,100,200):
    h=2
    while p[h]<2**lam: h+=1
    bc=b=0
    for s in range(-2*h,2*h+1):
        Rr=S(s,s+2*h); Rc=S(-s,2*h-s)
        b=max(b,lg(Rr)+lg(Rc)); bc=max(bc,math.ceil(lg(Rr))+math.ceil(lg(Rc)))
    hm=0
    while pre[hm+1]<2**lam: hm+=1
    bm=max(lg(pre[s+2*hm+1])+lg(pre[2*hm-s+1]) for s in range(-2*hm,2*hm+1))
    # hybrid: A's h but cumulative D
    bh=max(lg(pre[s+2*h+1])+lg(pre[2*h-s+1]) for s in range(-2*h,2*h+1))
    print(lam,h,"%.4f %.4f"%(bc/(4*lam),b/(4*lam)),"|",hm,"%.4f"%(bm/(4*lam)),"| A's h, cum D: %.4f"%(bh/(4*lam)))
print("line123 check: (lgRrow(0)+lgRcol(0))/(4 log2 p(h))")
for h in (64,512,3000):
    print(h,"lam=%.2f"%lg(p[h]),"%.4f"%((lg(S(0,2*h))+lg(S(0,2*h)))/(4*lg(p[h]))))
# SFA-8: two-piece identities, naming-count value 2*log2(sum 2^{a_j/2})/(4b)
print("two-piece min certified value; constraints: (i) sum 2^crow>=N^2, (ii) sum 2^ccol>=N^2, (iii) sum 2^min>=N; and literal-note premises only")
for b in range(2,13):
    Nn=2**b; best=9; arg=None; bestlit=9; arglit=None
    R=range(0,2*b+1)
    for r1 in R:
      for c1 in R:
        for r2 in R:
          for c2 in R:
            a1=r1+c1;a2=r2+c2
            val=2*math.log2(2**(a1/2)+2**(a2/2))/(4*b)
            okmin = 2**min(r1,c1)+2**min(r2,c2)>=Nn
            if okmin and max(a1,a2)>=2*b-1 and val<bestlit: bestlit=val;arglit=(r1,c1,r2,c2)
            if okmin and 2**r1+2**r2>=Nn*Nn and 2**c1+2**c2>=Nn*Nn and val<best: best=val;arg=(r1,c1,r2,c2)
    print(b,"full: %.4f"%best,arg,"maxa/(4b)=%.4f"%(max(arg[0]+arg[1],arg[2]+arg[3])/(4*b)),"| literal premises: %.4f"%bestlit,arglit)
# SFA-6
rho=2**-0.5
e=1.0;
for l in range(0,200001):
    if l in (10,100,1000,10000,100000,200000): print("SFA6 l=%d y=e/rho^l (scaled)=%.4f"%(l,e))
    e = e + (1/rho)/(l+1)   # y_{l+1}=y_l + delta_l rho^{-l-1}, delta_l=rho^l/(l+1)
