import math, itertools
from fractions import Fraction
# --- (1) general-formula counterexample: delta_l = rho^l/(l+1) is o(rho^l) but e_l/rho^l unbounded
rho=2**-0.5
e=0.5
for l in range(0,200001):
    if l in (10,100,1000,10000,100000,200000): print("l",l,"y_l=e_l/rho^l (tracked directly)",e)
    # track y directly: y_{l+1} = y_l + (1/(l+1))/rho
    e = e + (1.0/(l+1))/rho
# --- (2) thresholds p.29
for (k,r) in [(3,1),(3,5)]:
    l=0
    while 2**l <= (k*r)**2: l+=1
    print("k,r",k,r,"min l",l,"9*logK_l >=",9*(60*2**l-6*l-42))
print("e1 main text", 11/12+7/64, " alpha vals", math.log2(12/11)/4, math.log2(12/11), "0.9-brief alpha", math.log2(1/0.9)/4)
print("rank formula t=2,i=1,N=8:", sum(math.comb(2,z)*56**z*8**(2-z) for z in range(0,2)), " 2+log448", 2+math.log2(448), "2+log48", 2+math.log2(48), "log12", math.log2(12), math.log2(12)/4, 10.81/12, 7.58/8)
# --- (3) two-piece F2 bound: minimise certified 4b*rho = 2*log2(sqrt(R1C1)+sqrt(R2C2)) and max_j a_j
# constraints (real ranks): R1+R2>=N^2, C1+C2>=N^2, min(R1,C1)+min(R2,C2)>=N, ranks >=1 if piece nonzero
def best(b, integer_bits=True):
    N=2**b; bestv=None
    rng=range(0,2*b+1)
    for r1 in rng:
      for c1 in rng:
        for r2 in rng:
          for c2 in rng:
            if 2**r1+2**r2 < N*N or 2**c1+2**c2 < N*N: continue
            if 2**min(r1,c1)+2**min(r2,c2) < N: continue
            a1=r1+c1; a2=r2+c2
            cert=2*math.log2(2**(a1/2)+2**(a2/2))/(4*b)
            mx=max(a1,a2)/(4*b)
            if bestv is None or cert<bestv[0]: bestv=(cert,mx,(r1,c1,r2,c2))
    return bestv
for b in range(1,9):
    v=best(b); print("b",b,"min certified rho (2 pieces, integer bit costs) %.4f"%v[0],"max a_j/4b %.4f"%v[1],v[2],"3/4-1/(2b)=%.4f"%(0.75-0.5/b))
# continuous relaxation in real log-ranks: grid search
def best_real(b,steps=60):
    N=2.0**b; bv=None
    import random
    random.seed(1)
    for _ in range(400000):
        R1=N*N*random.random(); C1=N*N*random.random()
        if random.random()<0.5: R1=N*N
        if random.random()<0.5: C1=N**(2*random.random())
        R2=max(N*N-R1,0); C2=max(N*N-C1,0)
        need=N-min(R1,C1)
        if min(R2,C2)<need:
            if R2<need: R2=need
            if C2<need: C2=need
        if R1<1 or C1<1: continue
        R2=max(R2,1); C2=max(C2,1)
        val=math.sqrt(R1*C1)+math.sqrt(R2*C2)
        cert=2*math.log2(val)/(4*b)
        if bv is None or cert<bv: bv=cert
    return bv
for b in (3,6,12): print("b",b,"real-rank relaxation min certified rho ~ %.4f"%best_real(b))
