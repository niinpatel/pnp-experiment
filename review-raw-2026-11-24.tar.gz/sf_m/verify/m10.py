import math
N=14000
p=[0]*(N+1); p[0]=1
for n in range(1,N+1):
    t=0;k=1
    while True:
        g1=k*(3*k-1)//2; g2=k*(3*k+1)//2
        if g1>n: break
        sg=1 if k%2 else -1
        t+=sg*p[n-g1]
        if g2<=n: t+=sg*p[n-g2]
        k+=1
    p[n]=t
pf=[0]
for x in p: pf.append(pf[-1]+x)
def S(lo,hi):
    lo=max(lo,0); hi=min(hi,N)
    return pf[hi+1]-pf[lo] if hi>=lo else 0
def clog(x): return (x-1).bit_length()  # ceil log2
for lam in (20,25,50,100,200):
    # [A]: h least with p(h)>=2^lam
    h=next(E for E in range(N) if p[E]>=2**lam)
    best=0;bestc=0
    for s in range(-2*h,2*h+1):
        r=S(s,s+2*h); c=S(-s,2*h-s)
        if r>0 and c>0:
            best=max(best,math.log2(r)+math.log2(c)); bestc=max(bestc,clog(r)+clog(c))
    # note model: D cumulative, h least D(h)>=lam, D(s+2h)+D(2h-s)
    D=lambda E: math.log2(pf[E+1]) if E>=0 else float('-inf')
    h2=next(E for E in range(N) if D(E)>=lam)
    b2=max(D(s+2*h2)+D(2*h2-s) for s in range(-2*h2,2*h2+1))
    print(f"lam={lam} [A]: h={h} max(crow+ccol) ceil={bestc} real={best:.2f} rho={best/(4*lam):.4f} rho_ceil={bestc/(4*lam):.4f} | note-model: h={h2} rho={b2/(4*lam):.4f}")
