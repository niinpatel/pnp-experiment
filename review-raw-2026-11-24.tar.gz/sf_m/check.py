import math
from fractions import Fraction
print("closed forms")
for a in [0.5,0.6,0.75,1.0]:
    mu=2**(1/a-1)
    print(" a=%.2f mu=2^(1/a-1)=%.4f  mu^a/2=%.4f  2^-a=%.4f  2^(a-1)=%.4f  pigeon (2mu)^a=%.4f"%(a,mu,mu**a/2,2**-a,2**(a-1),(2*mu)**a))
a=math.log(2,3)
print(" a=log3(2)=%.4f (3/2)^a/2=%.4f 2^-a=%.4f"%(a,1.5**a/2,2**-a))
# Prop 4.24 bound
f=lambda mu: 0.5*(1+(mu-1)/(2*mu-1))
for mu in [1,1.26,1.5,1.587,2,3,10]:
    print(" Prop4.24 mu=%.3f bound=%.4f"%(mu,f(mu)))
print(" alpha' ceilings: log2(3/2)=%.4f log2(8/5)=%.4f"%(math.log2(1.5),math.log2(1.6)))
# class 1 window for a=3/4
a=0.75
print(" class1 a=.75: mu_min=2^(1/a-1)=%.4f mu_max=2^(1/(2a))=%.4f"%(2**(1/a-1),2**(1/(2*a))))
# class 2: concave, mu=2, D(2h)/D(h)=x -> rho=x/2 ; need x in [4/3, sqrt2)
print(" class2: 4/3/2=%.4f sqrt2/2=%.4f"%(4/6,2**.5/2))
# power profile, asymmetric windows H=h, W=w*h : rho = max_s (D(s+H)+D(W-s))/4, pigeon D(W+H)>=2
def rho_pw(a,W,H,n=20001):
    best=0
    for k in range(n):
        s=-H+(W+H)*k/(n-1)
        best=max(best,(max(s+H,0)**a+max(W-s,0)**a)/4)
    return best
print(" partition a=.5, H=1, W=3 (W+H=4): pigeon %s rho=%.4f"%(4**.5>=2, rho_pw(.5,3,1)))
print(" a=.5 H=1 W=2: pigeon %s"%(3**.5>=2))
# normalisation D(h)=kappa*lam, kappa>=1 (h least with D>=lam): power profile cE^a with D(h)=kappa
for kappa in [1.0,1.2]:
    a=.5
    # pigeon: D(2M)>=2 -> kappa*(2M)^a>=2 -> M>= (2/kappa)^(1/a)/2 ; rho=2*kappa*M^a/4
    M=(2/kappa)**(1/a)/2
    print(" kappa=%.1f a=.5: M_min=%.3f h, rho=%.4f"%(kappa,M,2*kappa*M**a/4))
# counted rho_B from exact partition numbers ([M] l.716-720 formula): r_s=log2 sum_{i=0}^{2h} p(s+i), c_s=log2 sum_i p(2h-s-i)
def parts(n):
    p=[1]+[0]*n
    for k in range(1,n+1):
        for j in range(k,n+1):
            p[j]+=p[j-k]
    return p
P=parts(40000)
def rhoB(lam):
    h=next(E for E in range(len(P)) if P[E]>=2**lam)
    pf=[0]
    for x in P: pf.append(pf[-1]+x)
    def S(lo,hi):  # sum p(lo..hi), p(neg)=0
        lo=max(lo,0)
        return pf[hi+1]-pf[lo] if hi>=lo else 0
    best=0
    for s in range(-2*h,2*h+1):
        r=S(s,s+2*h); c=S(-s,2*h-s)
        if r>0 and c>0:
            best=max(best,(math.log2(r)+math.log2(c))/(4*lam))
    return h,best
for lam in [20,64,200,256]:
    print(" partition counted rho_B lam=%d: h=%d rho=%.4f (x4=%.3f)"%((lam,)+rhoB(lam)+(4*rhoB(lam)[1],)))
